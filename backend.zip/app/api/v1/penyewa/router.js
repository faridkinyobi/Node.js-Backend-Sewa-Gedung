const express = require('express');
const router = express();

const {Creat, getAll, getOne, update, delet}=require('./controller')

const {authenticateUser,authorizeRoles} = require('../../../middlewares/auth');


router.post('/penyewa',authenticateUser,authorizeRoles('super admin',"admin"), Creat);
router.get('/penyewa',authenticateUser,authorizeRoles('super admin',"admin"), getAll);
router.get('/penyewa/:id',authenticateUser,authorizeRoles('super admin',"admin"), getOne);
router.put('/penyewa/:id',authenticateUser,authorizeRoles('super admin',"admin"), update);
router.delete('/penyewa/:id',authenticateUser,authorizeRoles('super admin',"admin"), delet);

module.exports= router;